
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Present extends StatefulWidget {
  String id;
  Present({this.id});
  @override
  _PresentState createState() => _PresentState();
}

class _PresentState extends State<Present> {
  @override
  Widget build(BuildContext context) {
    print('id is ${widget.id}');
    return  StreamBuilder<QuerySnapshot>(
      stream: Firestore.instance.collection('CompAtt').where('competition_id',isEqualTo: widget.id  ).snapshots(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasError)
          return new Text('Error: ${snapshot.error}');
        switch (snapshot.connectionState) {
          case ConnectionState.waiting: return new Text('Loading...');
          default:
            return new ListView(
              children: snapshot.data.documents.map((DocumentSnapshot document) {
                return new CCard(d: document,);
              }).toList(),
            );
        }
      },
    );;
  }
}

class CCard extends StatefulWidget {
  DocumentSnapshot d;
  CCard({this.d});
  @override
  _CCardState createState() => _CCardState();
}

class _CCardState extends State<CCard> {
  @override
  Widget build(BuildContext context) {
    return Card(child: Container(child: Column(
      children: <Widget>[
        new Text('${widget.d['team_name']}'),
        new Text('${widget.d['team_code']}'),

      ],
    ),));
  }
}
