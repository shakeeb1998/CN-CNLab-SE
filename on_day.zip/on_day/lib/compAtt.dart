import 'package:flutter/material.dart';

import 'package:flutter/material.dart';
import 'package:qr_reader/qr_reader.dart';
import 'package:dio/dio.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
class Attendance extends StatefulWidget {
  @override
  _AttendanceState createState() => _AttendanceState();
}

class _AttendanceState extends State<Attendance> {
  TextEditingController controller= new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Center(

            child: new RaisedButton(onPressed:()=>scane() ,child: new Text('scan'),),

          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: new TextFormField(
              controller: controller,
              style: TextStyle(),decoration: InputDecoration(labelText: "Enter Team Code",border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0))),),
          ),
          new RaisedButton(onPressed:()=>submit() ,child: new Text('Submit'),),

        ],
      ),
    );
  }
  submit()
  {
    getDetails(controller.text);

  }

  scane()
  async {
    String futureString = await new QRCodeReader()
        .setAutoFocusIntervalInMs(200) // default 5000
        .setForceAutoFocus(true) // default false
        .setTorchEnabled(false) // default false
        .setHandlePermissions(true) // default true
        .setExecuteAfterPermissionGranted(true) // default true
        .scan();
    print('scanned item is ${futureString}');
    getDetails(futureString);
  }

  getDetails(String code)
  async {
    Dio dio= new Dio();
    var a =await dio.get("https://be-api.procom19.com/api/pr-app/getTeamForAttendance/${code}");
    //Todo
    //whenn res empty

    print('rees ${a.data}');
    var b=await Firestore.instance.collection('CompAtt').where('code',isEqualTo: a.data[0]['code']).limit(1).getDocuments();
    if(b.documents.length>0)
    {
      print('ids given');
      alert3(context);
    }
    else
    {
      if(!a.data[0]['payment'])
      {
        print('unpaid');
        alert2(context);
      }
      else
      {
        print('give id');
        ackAlert(context,a.data[0]);
      }
    }

  }

  Future<void> ackAlert(BuildContext context,var a) {
    Widget widget= new Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children:listBuilder(a),
    );
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Status'),
          content: widget ,
          actions: <Widget>[
            FlatButton(
              child: Text('Mark Attendance'),
              onPressed: () async {
                await markAttendance(a);
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );

  }
  markAttendance(var a)
  async {
    await Firestore.instance.collection('CompAtt').add({
      "members":a["members_name"],
      'team_name':a['team_name'],
      'team_code':a['team_code'],
      'competition':a['competition'],
      'competition_id':a['competition_id'],



    });
  }

  List<Widget>listBuilder(var a)
  {
    List <Widget>l=List();

    l.add(new Text("Team Name"));
    l.add(Padding(
      padding: const EdgeInsets.all(8.0),
      child: new Text(a["team_name"].toString()),
    ));
    l.add(new Text("Competition"));
    l.add(Padding(
      padding: const EdgeInsets.all(8.0),
      child: new Text(a["competition"].toString()),
    ));

    l.add(Padding(
      padding: const EdgeInsets.all(8.0),
      child: new Text('Members'),
    ));

    for (var i in a['members_name'])
    {
      l.add(new Text(i.toString()));
    }


    return l;
  }
  Future<void> alert2(BuildContext context) {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Status'),
          content: const Text('Payment not verified'),
          actions: <Widget>[
            FlatButton(
              child: Text('Ok'),
              onPressed: () {

                Navigator.of(context).pop();

              },
            ),
          ],
        );
      },
    );
  }
  Future<void> alert3(BuildContext context) {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Status'),
          content: const Text('Already Marked'),
          actions: <Widget>[
            FlatButton(
              child: Text('Ok'),
              onPressed: () {

                Navigator.of(context).pop();

              },
            ),
          ],
        );
      },
    );
  }
}


